package com.rulesservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RulesServiceApplicationTests {

	@Test
	void contextLoads() {
		
	}

}
