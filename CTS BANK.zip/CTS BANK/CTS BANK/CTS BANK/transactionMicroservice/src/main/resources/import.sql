INSERT INTO TRANSACTION(id, source_Account_Id,source_Owner_Name,target_Account_Id,target_Owner_Name,amount,initiation_Date,reference)VALUES (1, 10054546,'Akash', 12345, 'Sharath', 10000.00, '2022-02-16 10:30', 'transfer');

