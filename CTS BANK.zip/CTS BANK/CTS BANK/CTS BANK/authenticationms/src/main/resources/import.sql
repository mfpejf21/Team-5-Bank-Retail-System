insert into appuser (userid,username,password,role) values ('EMPLOYEE101','emp','emp','EMPLOYEE');
insert into appuser (userid,username,password,role) values ('Employee','employee','emp','EMPLOYEE');
insert into appuser (userid,username,password,role) values ('CUSTOMER101','cust','cust','CUSTOMER');
insert into appuser (userid,username,password,role) values ('Sharath','sharath','sha','EMPLOYEE');
insert into appuser (userid,username,password,role) values ('CUSTOMER102','cust','cust','CUSTOMER');