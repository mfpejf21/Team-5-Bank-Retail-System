insert into CUSTOMER_ENTITY values('CUSTOMER101','Chennai','1999-02-02','124','cust','cust')
insert into CUSTOMER_ENTITY values('CUSTOMER102','Chennai','1999-02-02','125','cust','cust')
