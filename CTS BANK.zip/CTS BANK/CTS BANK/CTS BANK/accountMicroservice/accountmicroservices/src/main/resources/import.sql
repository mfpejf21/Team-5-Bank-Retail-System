INSERT INTO ACCOUNT(account_Id,customer_Id,current_Balance,account_Type,owner_Name) VALUES(10054546,'CUSTOMER101',1071.48, 'Savings', 'Sharath');

INSERT INTO ACCOUNT(account_Id,customer_Id,current_Balance,account_Type,owner_Name) VALUES (10054547,'CUSTOMER102',10000.00, 'Savings', 'Akash');